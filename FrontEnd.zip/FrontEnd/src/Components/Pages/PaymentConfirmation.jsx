import React from 'react'
import BookingConfirmationTemplate from '../Templates/BookingConfirmationTemplate'
export default function PaymentConfirmation() {
  return (
    <div>
      <BookingConfirmationTemplate/>
    </div>
  )
}
