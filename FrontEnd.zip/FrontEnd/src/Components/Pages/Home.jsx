import React from 'react'
import GovernatesPage from '../Templates/choosegover'
export default function Home() {
  return (
    <div>
      <GovernatesPage/>
    </div>
  )
}
