import React from 'react'
import PaymentTemplate from '../Templates/PaymentTemplate'
export default function Payment() {
  return (
    <div>
      <PaymentTemplate/>
    </div>
  )
}
