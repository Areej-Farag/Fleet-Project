import React from "react";
import "../Styles/atoms.css";

const Loader = () => {
  return <div className="loader"></div>;
};

export default Loader;
